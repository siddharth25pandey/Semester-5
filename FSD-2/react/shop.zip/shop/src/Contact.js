import React from "react";

const Contact = () => { 
    var data=[
        {
            "id": 1,
            "title": "Welcome to Home",
            "content": "this is home content"
        },
        {
            "id": 2,
            "title": "Welcome to About",
            "content": "this is about content"
        },
        {
            "id": 3,
            "title": "Welcome to Contact",
            "content": "this is contact content"
        },
        {   "id":4,
            "title":"Welcome to Employee",
            "content":"this is empoyee content"
        }
    ];
	return <> <h1>Hello, Contact</h1><h2>{data[2].title}, {data[2].content}</h2></>;
};
export default Contact;