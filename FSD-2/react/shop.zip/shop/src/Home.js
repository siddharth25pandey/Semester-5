import { Button } from "@material-ui/core";
import React from "react";
import Data from "./data.json";

function Home() {
    return (<>
    <br/><h1>Hello, Home (Rendering Complete Data from JSON</h1>
        <div>
            {
             Data.map(post => {
               //
                return (

                    <>
                        {
                            <div>
                                <h2>{post.title}, {post.content}, {post.id}</h2>
                            </div>
                        }
                    </>

                )
            })
            }
        </div>
       
    </>)
}
export default Home;