import './App.css';
import Home from "./Home";
import About from "./About";
import Contact from "./Contact";
import Employee from "./Employee";

import { BrowserRouter as Router, Link, Switch, Route } from 'react-router-dom';
function App() {
  var data=[
    {
        "id": 1,
        "title": "Welcome to Home",
        "content": "this is home content"
    },
    {
        "id": 2,
        "title": "Welcome to About",
        "content": "this is about content"
    },
    {
        "id": 3,
        "title": "Welcome to Contact",
        "content": "this is contact content"
    },
    {   "id":4,
        "title":"Welcome to Employee",
        "content":"this is empoyee content"
    }
];
  return (
    <div className="navbar">
      <Router>


        <Link to="/">Home</Link>


        <Link to="/about" >About</Link>


        <Link to="/contact">Contact</Link>


        <Link to="/employee">Employee</Link>

        <Switch>
          <Route exact path="/" component={Home}><Home /></Route>
          <Route exact path="/about" component={About}><About /></Route>
          <Route exact path="/contact" component={Contact}><Contact /></Route>
          <Route exact path="/employee" component={Employee}><Employee /></Route>
        </Switch>

      </Router>
    </div>

  );
}

export default App;
